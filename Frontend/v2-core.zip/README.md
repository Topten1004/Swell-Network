# SwellNetwork

[![Website](https://img.shields.io/website?url=http%3A%2F%2Fswellnetwork.io)](https://www.swellnetwork.io)
[![Twitter Follow](https://img.shields.io/twitter/follow/swellnetworkio?style=social)](https://twitter.com/swellnetworkio)
[![Discord](https://img.shields.io/discord/907097149521678357?label=Discord&logo=discord&style=social)](https://discord.gg/SeMQbGbeqC)

The most decentralized, transparent, non-custodial and liquid staking protocol.