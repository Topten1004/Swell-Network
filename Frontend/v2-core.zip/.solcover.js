module.exports = {
    skipFiles: ['tests', 'interfaces']
  };